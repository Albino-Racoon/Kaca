import pygame
from Direction import Direction


class Snake(pygame.sprite.Sprite):
    def __init__(self):
        # head's original image
        self.original_image = pygame.image.load("images/head.png")
        # auxiliary image that will change when the direction changes
        self.image = pygame.transform.rotate(self.original_image, 0)
        # head coordinates
        self.rect = self.image.get_rect(center=(12*32+16, 9*32+16))
        # variables responsible for direction and those connected to it
        self.direction = Direction.UP
        self.new_direction = Direction.UP

    def change_direction(self, direction):
        possible_change = True
        if direction == Direction.UP and self.direction == Direction.DOWN:
            possible_change = False
        if direction == Direction.DOWN and self.direction == Direction.UP:
            possible_change = False
        if direction == Direction.LEFT and self.direction == Direction.RIGHT:
            possible_change = False
        if direction == Direction.RIGHT and self.direction == Direction.LEFT:
            possible_change = False
        if possible_change:
            self.new_direction = direction

    def update(self):
        self.direction = self.new_direction
        self.image = pygame.transform.rotate(
            self.original_image, (self.direction.value*-90))

        if self.direction == Direction.UP:
            self.rect.move_ip(0, -32)
        if self.direction == Direction.RIGHT:
            self.rect.move_ip(32, 0)
        if self.direction == Direction.LEFT:
            self.rect.move_ip(-32, 0)
        if self.direction == Direction.DOWN:
            self.rect.move_ip(0, 32)
